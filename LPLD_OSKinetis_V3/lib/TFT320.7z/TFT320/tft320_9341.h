#ifndef __TFT320_9341_H
#define __TFT320_9341_H

#include "HW_GPIO.h"

//ע��Ӵ�������������Դ��JLINK�����ݣ����ƿأ���Ҫ�����ι̣��������ʾ����
//TFT320 3.3V����

/* LCD color */
#define White          0xffff       //RGB 565.
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0




//����TFT320 ���ݶ˿� ( DB0~DB15  ) ----------------------------------------PORTC
#define TFT320_DATA16(x)         PTC_W0_OUT(x)//дDB0~DB15����

#define TFT320_RS(x)    LPLD_GPIO_Output_b(PTB,23,x)            //дRS����
#define TFT320_RW(x)    LPLD_GPIO_Output_b(PTB,22,x)            //дRW����
#define TFT320_RD(x)    LPLD_GPIO_Output_b(PTB,21,x)        //дCS����
#define TFT320_RES(x)   LPLD_GPIO_Output_b(PTB,19,x)            //дRES����
#define TFT320_CS(x)    LPLD_GPIO_Output_b(PTB,20,x)            //дCS����

/*
#define TFT320_RS(x)    LPLD_GPIO_Output_b(PTB,18,x)            //дRS����
#define TFT320_RW(x)    LPLD_GPIO_Output_b(PTB,21,x)            //дRW����
#define TFT320_RD(x)    LPLD_GPIO_Output_b(PTB,20,x)        //дCS����
#define TFT320_RES(x)   LPLD_GPIO_Output_b(PTB,22,x)            //дRES����
#define TFT320_CS(x)    LPLD_GPIO_Output_b(PTB,23,x)            //дCS����
*/
//���ú���

void PTC_W0_OUT(uint16_t x);

/****           TFT320��ʼ��                      *****/
void TFT320_INIT(void);

/*             TFT320��ʾ                        */
void TFT320_xian();

/***********            ����       bColor ָ��������ɫ              **************/
void TFT320_ClearScreen(uint16_t bColor);

/**********      д8*16����                          ***********/
void TFT320_Write_8x16(uint16_t x,  uint16_t y,  uint8_t c, uint16_t fColor,  uint16_t bColor);

/**********      д16*16����                          ***********/
void TFT320_Write_16x16(uint16_t x,  uint16_t y,  uint8_t c[2], uint16_t fColor,  uint16_t bColor);

/**********      д32x32����                          ***********/
void TFT320_Write_32x32(uint16_t x,  uint16_t y, uint8_t c[2], uint16_t fColor,  uint16_t bColor);

/***************   д8*16�ַ���   ��   16*16 ����                           ******************/
void TFT320_Write_String(uint16_t x,  uint16_t y,  uint8_t *s, uint16_t fColor,  uint16_t bColor);

/****            ��ʾ  R  G  B  ��ɫ                           *****/
void TFT320_Show_RGB(uint16_t x0, uint16_t x1, uint16_t y0, uint16_t y1, uint16_t Color);
/***             //���ص�����                               *****/
void TFT320_PPScreen();

/****            ��ʾ ����                         *****/
void TFT320_Show_Color_Bar(void);


/********            д����/����   cmd=0,д���  cmd=1   д����              ******** */
void TFT320_Write_Data_Cmd(uint8_t cmd, uint16_t dat);

/**********           ��ĳ�� x �Ĵ�������ַ��     д ����                **********/
void TFT320_Init_data(uint16_t x,  uint16_t y);

/*************************������ʾ����*******************************

         x0:  ������X�����н�С��
     x1:  ������X�����нϴ���
     y0:  ������Y�����н�С��
     y1:  ������Y�����нϴ���
**********************************************************************************/
static void TFT320_LCD_SetPos(uint16_t x0, uint16_t x1, uint16_t y0, uint16_t y1);

void TFT_display_number_6x8(int16_t x, int16_t y, int16_t number, uint16_t fColor,  uint16_t bColor);
void TFT_display_unsign_number_6x8(int16_t x, int16_t y, uint16_t number, uint16_t fColor,  uint16_t bColor);
void TFT_display_unsign32_number_6x8(int16_t x, int16_t y, uint32_t number, uint16_t fColor,  uint16_t bColor);
void TFT_display_unsign32_number_small(int16_t x, int16_t y, uint32_t number, uint16_t fColor,  uint16_t bColor); //xiaoshu
void TFT320_Point_Chart(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor);
void TFT320_Point_Chart1(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor);
void TFT320_Point_Chart2(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor);
void TFT320_Point_Chart3(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor);
void int16_to_string(int16_t number, char *str);
void uint16_to_string(uint16_t number, char *str);
void uint32_to_string(uint32_t number, char *str);
void uint32_small_to_string(uint32_t number, char *str);
void TFT320_Write_12x24(uint16_t x,  uint16_t y,  uint8_t c, uint16_t fColor,  uint16_t bColor);
void TFT320_Write_12x24_String(uint16_t x,  uint16_t y,  uint8_t *s, uint16_t fColor,  uint16_t bColor);
void TFT320_write_Chart();//����
void TFT_display_number3_small(int16_t x, int16_t y, int number, uint16_t fColor,  uint16_t bColor);
void TFT320_write_Bar_Chart1(float *data);
void TFT_display_floatzidong_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor);
void TFT_display_float5_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor);
void TFT_display_float4_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor);
void TFT_display_float3_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor);
void TFT_display_float2_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor);
void TFT_display_float_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor);
void TFT_display_char(int16_t x, int16_t y, char a, uint16_t fColor,  uint16_t bColor);
void  Touch_start();
void Touch_spistar();
#endif
