#include "common.h"

#include "HW_GPIO.h"
#include "tft320_9341.h"

#include "8X16.H" //����8*16�ַ�
#include "GB1616.H" //����16*16�ַ�
#include "GB3232.h"  //����32*32�ַ�
#include "photo.h"  //ͼƬ
#include "zifu.h"

#define time_delay_ms(x) delay(x)
#define time_delay_us(x) delay_us(x)


#define LCD_WR_REG(x) TFT320_Write_Data_Cmd(0,x)
#define LCD_WR_DATA(x) TFT320_Write_Data_Cmd(1,x)


// ------------------  ASCII��ģ�����ݱ� ------------------------ //
// �����0x20~0x7e                                                //
// �ֿ�: C:\Users\tang\Desktop\tft320_9341\tft320_9341\lcd����ȡģ����\lcd����ȡģ����\Asc12x24E.dat ����ȡģ���λ//
// -------------------------------------------------------------- //


void delay(uint32_t i)
{
    uint32_t j = 48000, k = 1000 * i;
    for (; j > 0; j--)
        for (; k > 0; k--);
}

void delay_us(uint32_t i)
{
    uint32_t j = 48, k = 1000 * i;
    for (; j > 0; j--)
        for (; k > 0; k--);
}

void PTC_W0_OUT(uint16_t x)
{
    PTC->PDOR &= (0xFFFF0000);
    PTC->PDOR |= x;
}

/****           TFT320��ʼ��                      *****/
void TFT320_INIT(void)
{
    uint8_t i = 0;
    for (i = 0; i < 16; i++) { //�˿ڳ�ʼ��
        LPLD_GPIO_Output_b(PTC, i, 1);
    }
    //  LPLD_GPIO_Output_b(PTB,10,0);
    //  LPLD_GPIO_Output_b(PTB,11,0);
    for (i = 0; i < 5; i++) {
        LPLD_GPIO_Output_b(PTB, 19 + i, 1);
    }
    //��չ����߲�ͬ
    //  LPLD_GPIO_Input_b(PTB, 19);
    //  LPLD_GPIO_Input_b(PTB, 16);
    TFT320_CS(1);
    TFT320_RD(1);
    TFT320_RW(1);
    time_delay_ms(5);
    TFT320_RES(0);
    time_delay_ms(15);
    TFT320_RES(1);
    time_delay_ms(100);
    //************* Start Initial Sequence **********//
    LCD_WR_REG(0xcf);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0xc1);
    LCD_WR_DATA(0x30);
    LCD_WR_REG(0xed);
    LCD_WR_DATA(0x64);
    LCD_WR_DATA(0x03);
    LCD_WR_DATA(0x12);
    LCD_WR_DATA(0x81);
    LCD_WR_REG(0xcb);
    LCD_WR_DATA(0x39);
    LCD_WR_DATA(0x2c);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x34);
    LCD_WR_DATA(0x02);
    LCD_WR_REG(0xea);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x00);
    LCD_WR_REG(0xe8);
    LCD_WR_DATA(0x85);
    LCD_WR_DATA(0x10);
    LCD_WR_DATA(0x79);
    LCD_WR_REG(0xC0); //Power control
    LCD_WR_DATA(0x23); //VRH[5:0]
    LCD_WR_REG(0xC1); //Power control
    LCD_WR_DATA(0x11); //SAP[2:0];BT[3:0]
    LCD_WR_REG(0xC2);
    LCD_WR_DATA(0x11);
    LCD_WR_REG(0xC5); //VCM control
    LCD_WR_DATA(0x3d);
    LCD_WR_DATA(0x30);
    LCD_WR_REG(0xc7);
    LCD_WR_DATA(0xaa);
    LCD_WR_REG(0x3A);
    LCD_WR_DATA(0x55);
    LCD_WR_REG(0x36); // Memory Access Control
    LCD_WR_DATA(0x08);
    LCD_WR_REG(0xB1); // Frame Rate Control
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x11);
    LCD_WR_REG(0xB6); // Display Function Control
    LCD_WR_DATA(0x0a);
    LCD_WR_DATA(0xa2);
    LCD_WR_REG(0xF2); // 3Gamma Function Disable
    LCD_WR_DATA(0x00);
    LCD_WR_REG(0xF7);
    LCD_WR_DATA(0x20);
    LCD_WR_REG(0xF1);
    LCD_WR_DATA(0x01);
    LCD_WR_DATA(0x30);
    LCD_WR_REG(0x26); //Gamma curve selected
    LCD_WR_DATA(0x01);
    LCD_WR_REG(0xE0); //Set Gamma
    LCD_WR_DATA(0x0f);
    LCD_WR_DATA(0x3f);
    LCD_WR_DATA(0x2f);
    LCD_WR_DATA(0x0c);
    LCD_WR_DATA(0x10);
    LCD_WR_DATA(0x0a);
    LCD_WR_DATA(0x53);
    LCD_WR_DATA(0xd5);
    LCD_WR_DATA(0x40);
    LCD_WR_DATA(0x0a);
    LCD_WR_DATA(0x13);
    LCD_WR_DATA(0x03);
    LCD_WR_DATA(0x08);
    LCD_WR_DATA(0x03);
    LCD_WR_DATA(0x00);
    LCD_WR_REG(0xE1); //Set Gamma
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x10);
    LCD_WR_DATA(0x03);
    LCD_WR_DATA(0x0f);
    LCD_WR_DATA(0x05);
    LCD_WR_DATA(0x2c);
    LCD_WR_DATA(0xa2);
    LCD_WR_DATA(0x3f);
    LCD_WR_DATA(0x05);
    LCD_WR_DATA(0x0e);
    LCD_WR_DATA(0x0c);
    LCD_WR_DATA(0x37);
    LCD_WR_DATA(0x3c);
    LCD_WR_DATA(0x0F);
    LCD_WR_REG(0x11); //Exit Sleep
    time_delay_ms(100);//�˴�����Ҫ��ʱ80ms���߸���
    LCD_WR_REG(0x29); //
}

/********            д����/����   cmd=0,д���  cmd=1   д����              ******** */
void TFT320_Write_Data_Cmd(uint8_t cmd, uint16_t dat)
{
    TFT320_CS(0);
    if (cmd == 0)
        TFT320_RS(0);
    else
        TFT320_RS(1);
    TFT320_DATA16(dat);
    TFT320_RW(0);
    TFT320_RW(1);
    TFT320_CS(1);
}

/**********           ��ĳ�� x �Ĵ�������ַ��     д ����                **********/
void TFT320_Init_data(uint16_t x,  uint16_t y)
{
    TFT320_Write_Data_Cmd(0, x); //д����
    TFT320_Write_Data_Cmd(1, y); //д����
}

/*************************������ʾ����*******************************
         x0:  ������X�����н�С��
     x1:  ������X�����нϴ���
     y0:  ������Y�����н�С��
     y1:  ������Y�����нϴ���
**********************************************************************************/
static void TFT320_LCD_SetPos(uint16_t x0, uint16_t x1, uint16_t y0, uint16_t y1)
{
    LCD_WR_REG(0x2A);
    LCD_WR_DATA(x0 >> 8);
    LCD_WR_DATA(x0);
    LCD_WR_DATA(x1 >> 8);
    LCD_WR_DATA(x1);
    LCD_WR_REG(0x2B);
    LCD_WR_DATA(y0 >> 8);
    LCD_WR_DATA(y0);
    LCD_WR_DATA(y1 >> 8);
    LCD_WR_DATA(y1);
    LCD_WR_REG(0x2c);
}

void TFT320_PPScreen()  //���ص�����
{
    uint16_t i, j, k = 0;
    TFT320_LCD_SetPos(0, 239, 0, 319);
    for (i = 0; i < 320; i++) {
        for (j = 0; j < 240; j++) {
            TFT320_Write_Data_Cmd(1 , k += 10);
        }
    }
}

/***********            ����       bColor ָ��������ɫ              **************/
void TFT320_ClearScreen(uint16_t bColor)
{
    uint16_t i, j;
    TFT320_LCD_SetPos(0, 239, 0, 319);
    for (i = 0; i < 320; i++) {
        for (j = 0; j < 240; j++) {
            TFT320_Write_Data_Cmd(1 , bColor);
        }
    }
}

/**********      д8*16�ַ�                          ***********/
void TFT320_Write_8x16(uint16_t x,  uint16_t y,  uint8_t c, uint16_t fColor,  uint16_t bColor)
{
    uint16_t i, j;
    uint16_t m;
    TFT320_LCD_SetPos(x, x + 8 - 1, y, y + 16 - 1);
    for (i = 0; i < 16; i++) {
        m = Font8x16[c * 16 + i];
        for (j = 0; j < 8; j++) {
            if ((m & 0x80) == 0x80)  //������λ��1
                TFT320_Write_Data_Cmd(1,  fColor);
            else
                TFT320_Write_Data_Cmd(1,  bColor);
            m <<= 1;
        }
    }
}

/**********      д16*16����                          ***********/
void TFT320_Write_16x16(uint16_t x,  uint16_t y,  uint8_t c[2], uint16_t fColor,  uint16_t bColor)
{
    uint16_t i, j, k;
    uint16_t m;
    TFT320_LCD_SetPos(x, x + 16 - 1, y, y + 16 - 1);
    for (k = 0; k < 30; k++) { //64��ʾ�Խ����ֿ��еĸ�����ѭ����ѯ����
        if ((codeGB_16[k].Index[0] == c[0]) && (codeGB_16[k].Index[1] == c[1])) {
            for (i = 0; i < 32; i++) {
                m = codeGB_16[k]. Msk[i];
                for (j = 0; j < 8; j++) {
                    if ((m << j) & 0x80)    //������λ��1
                        TFT320_Write_Data_Cmd(1,  fColor);
                    else
                        TFT320_Write_Data_Cmd(1,  bColor);
                }
            }
        }
    }
}


/**********      д32x32����                          ***********/
void TFT320_Write_32x32(uint16_t x,  uint16_t y, uint8_t c[2], uint16_t fColor,  uint16_t bColor)
{
    uint16_t i, j, k;
    uint16_t m;
    TFT320_LCD_SetPos(x, x + 32 - 1, y, y + 32 - 1);
    for (k = 0; k < 15; k++) { //15��ʾ�Խ����ֿ��еĸ�����ѭ����ѯ����
        if ((codeGB_32[k].Index[0] == c[0]) && (codeGB_32[k].Index[1] == c[1])) {
            for (i = 0; i < 128; i++) {
                m = codeGB_32[k]. Msk[i];
                for (j = 0; j < 8; j++) {
                    if ((m << j) & 0x80)    //������λ��1
                        TFT320_Write_Data_Cmd(1,  fColor);
                    else
                        TFT320_Write_Data_Cmd(1,  bColor);
                }
            }
        }
    }
}

/***************   32*32 ����                           ******************/
void TFT320_Write_String32X32(uint16_t x,  uint16_t y,  uint8_t *s, uint16_t fColor,  uint16_t bColor)
{
    uint16_t l = 0;
    while (*s) {
        TFT320_Write_32x32(x + l * 32 ,   y, (uint8_t *)s,  fColor,   bColor);
        s += 2;
        l++;
    }
}


/**********      д12*24 �ַ�                          ***********/
void TFT320_Write_12x24(uint16_t x,  uint16_t y,  uint8_t c, uint16_t fColor,  uint16_t bColor)
{
    uint16_t i, j;
    uint8_t m;
    TFT320_LCD_SetPos(x, x + 16 - 1, y, y + 24 - 1);
    if (c >= 0x20) {
        for (i = 0; i < 48; i++) {
            //   m=Ascii12X24[c-0x20][i];
            for (j = 0; j < 8; j++) {
                if ((m << j) & 0x80)    //������λ��1
                    TFT320_Write_Data_Cmd(1,  fColor);
                else
                    TFT320_Write_Data_Cmd(1,  bColor);
            }
        }
    }
}

void TFT320_Write_12x24_String(uint16_t x, uint16_t y, uint8_t *s, uint16_t fColor, uint16_t bColor)
{
    uint8_t l = 0;
    while (*s) {
        TFT320_Write_12x24(x + l * 13 ,   y,  *s,  fColor,   bColor);
        s++;
        l++;//λ��++
    }
}


/***************   д8*16�ַ���   ��   16*16 ����                           ******************/
void TFT320_Write_String(uint16_t x,  uint16_t y,  uint8_t *s, uint16_t fColor,  uint16_t bColor)
{
    uint16_t l = 0;
    while (*s) {
        if (*s < 0x80) { //*s<0x80   ���ַ���S���ַ������Ǻ���
            TFT320_Write_8x16(x + l * 8 ,   y,  *s,  fColor,   bColor);
            s++;
            l++;//λ��++
        }
        else {
            TFT320_Write_16x16(x + l * 16 ,   y, (uint8_t *)s,  fColor,   bColor);
            s += 2;
            l++;
        }
    }
}


/****            ��ʾ  R  G  B  ��ɫ                           *****/
void TFT320_Show_RGB(uint16_t x0, uint16_t x1, uint16_t y0, uint16_t y1, uint16_t Color)
{
    uint16_t i, j;
    TFT320_LCD_SetPos(x0, x1, y0, y1);
    for (i = y0; i <= y1; i++) {
        for (j = x0; j <= x1; j++) {
            TFT320_Write_Data_Cmd(1, Color); //д����
        }
    }
}


/****            ��ʾ ����                         *****/
void TFT320_Show_Color_Bar(void)
{
    uint16_t V, H;
    TFT320_LCD_SetPos(0, 239, 0, 319);
    for (H = 0; H < 240; H++) {
        for (V = 0; V < 40; V++) {
            TFT320_Write_Data_Cmd(1, Red); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 40; V < 80; V++) {
            TFT320_Write_Data_Cmd(1, Green); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 80; V < 120; V++) {
            TFT320_Write_Data_Cmd(1, Blue); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 120; V < 160; V++) {
            TFT320_Write_Data_Cmd(1, Yellow); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 160; V < 200; V++) {
            TFT320_Write_Data_Cmd(1, Magenta); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 200; V < 240; V++) {
            TFT320_Write_Data_Cmd(1, White); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 240; V < 280; V++) {
            TFT320_Write_Data_Cmd(1, Black); //д����
        }
    }
    for (H = 0; H < 240; H++) {
        for (V = 280; V < 320; V++) {
            TFT320_Write_Data_Cmd(1, Red); //д����
        }
    }
}

/****    x ,y ����ʾλ��        ��ʾ ͼƬ xx * xy  ��С����Ƭ                        *****/
void TFT320_Show_photo(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, uint8_t pho[])
{
    uint16_t j = 0;
    TFT320_LCD_SetPos(x, x + xx - 1, y, y + yy - 1);
    for (j = 0; j < (xx * yy); j++) {
        TFT320_Write_Data_Cmd(1, (pho[j * 2 + 1] << 8) | pho[j * 2]); //д����
        //DELAY_MS(100);
    }
}

/*
��ʾ���ִ�С���ַ�
x:��ʼ��ʾ�� X ����     x<240
y:��ʼ��ʾ�� Y ����     Y<320
xx: ����Ĵ�С
yy:����Ĵ�С
*/
void TFT320_Write_zifu(uint16_t x,  uint16_t y,  uint8_t xx, uint8_t yy, uint8_t ch[], uint16_t fColor,  uint16_t bColor)
{
    uint16_t i, j;
    uint16_t m;
    TFT320_LCD_SetPos(x, x + xx - 1, y, y + yy - 1);
    TFT320_LCD_SetPos(x, x + xx - 1, y, y + yy - 1);
    for (i = 0; i < ((xx * yy) / 8); i++)
        //for(i=0;i<(64*8);i++)
    {
        m = ch[i];
        for (j = 0; j < 8; j++) {
            if ((m << j) & 0x80)    //������λ��1
                TFT320_Write_Data_Cmd(1,  fColor);
            else
                TFT320_Write_Data_Cmd(1,  bColor);
        }
    }
}

/*             TFT320��ʾ                        */
void TFT320_xian()
{
    //    TFT320_Write_String32X32(0,  70,  "����ʦ����ѧ��", Red,  White);
    TFT320_Write_String32X32(0,  102,  "���������ѧԺ", Red,  White);
    TFT320_Write_String(0, 0,  "123456789abcdefghijklmnopqrstu", Red,  Blue2);  //д������ĸ�ַ���
    TFT320_Write_String(0, 16,  "vwxyz", Blue2,  Red);  //д������ĸ�ַ���
    TFT320_Write_String(0, 150,  "Ӧ�õ��Ӽ�������", Red,  Blue2);  //д������ĸ�ַ���
}



void TFT_display_number_6x8(int16_t x, int16_t y, int16_t number, uint16_t fColor,  uint16_t bColor)
{
    char str[5] = {32, 32, 32, 32, 32};     //32�����ո�ȫ����ʼ��Ϊ��
    int16_to_string(number, str);
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);   //д������ĸ�ַ���
}
void TFT_display_unsign_number_6x8(int16_t x, int16_t y, uint16_t number, uint16_t fColor,  uint16_t bColor)
{
    char str[6] = {32, 32, 32, 32, 32, 32};    //32�����ո�ȫ����ʼ��Ϊ��
    uint16_to_string(number, str);
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);   //д������ĸ�ַ���
}
void TFT_display_unsign32_number_6x8(int16_t x, int16_t y, uint32_t number, uint16_t fColor,  uint16_t bColor)
{
    char str[8] = {32, 32, 32, 32, 32, 32, 32, 32};  //32�����ո�ȫ����ʼ��Ϊ��
    str[0] = number / 10000000 + '0';
    str[1] = number % 10000000 / 1000000 + '0';
    str[2] = number % 1000000 / 100000 + '0';
    str[3] = number % 100000 / 10000 + '0';
    str[4] = number % 10000 / 1000 + '0';
    str[5] = number % 1000 / 100 + '0';
    str[6] = number % 100 / 10 + '0';
    str[7] = number % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);   //д������ĸ�ַ���
}

void TFT_display_unsign32_number_small(int16_t x, int16_t y, uint32_t number, uint16_t fColor,  uint16_t bColor) //С��
{
    char str[10] = {32, 32, 32, 32, 32, 32, 32, 32, 32, 32}; //32�����ո�ȫ����ʼ��Ϊ��
    uint32_small_to_string(number, str);
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);   //д������ĸ�ַ���
}

void TFT_display_float_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor)
{
    char str[7] = {32, 32, 32, 32, 32, 32, 32};   //32�����ո�ȫ����ʼ��Ϊ��
    if (number >= 0)
        str[0] = ' ';
    else {
        str[0] = '-';
        number = -number;
    }
    str[1] = (int)(number) / 10 + '0';
    str[2] = (int)(number) % 10 + '0';
    str[3] = '.';
    str[4] = (int)(number * 10) % 10 + '0';
    str[5] = (int)(number * 100) % 10 + '0';
    str[6] = (int)(number * 1000) % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}
void TFT_display_float2_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor)
{
    char str[5] = {32, 32, 32, 32, 32};     //32�����ո�ȫ����ʼ��Ϊ��
    str[0] = (int)(number) / 10 + '0';
    str[1] = (int)(number) % 10 + '0';
    str[2] = '.';
    str[3] = (int)(number * 10) % 10 + '0';
    str[4] = (int)(number * 100) % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}

void TFT_display_number3_small(int16_t x, int16_t y, int number, uint16_t fColor,  uint16_t bColor)
{
    char str[3] = {32, 32, 32};       //32�����ո�ȫ����ʼ��Ϊ��
    str[0] = (int)(number) / 100 + '0';
    str[1] = (int)(number) % 100 / 10 + '0';
    str[2] = (int)(number) % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}

void TFT_display_floatzidong_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor)
{
    char str[7] = {32, 32, 32, 32, 32, 32, 32};   //32�����ո�ȫ����ʼ��Ϊ��
    if (number >= 0)
        str[0] = ' ';
    else {
        str[0] = '-';
        number = -number;
    }
    if ((number / 1000) >= 0.9) {
        str[1] = (int)(number) / 1000 + '0';
        str[2] = (int)(number) % 1000 / 100 + '0';
        str[3] = (int)(number) % 100 / 10 + '0';
        str[4] = (int)(number) % 10 + '0';
        str[5] = '.';
        str[6] = (int)(number * 10) % 10 + '0';
    }
    else if ((number / 100) >= 0.9) {
        str[1] = (int)(number) / 100 + '0';
        str[2] = (int)(number) % 100 / 10 + '0';
        str[3] = (int)(number) % 10 + '0';
        str[4] = '.';
        str[5] = (int)(number * 10) % 10 + '0';
        str[6] = (int)(number * 100) % 10 + '0';
    }
    else {
        str[1] = (int)(number) / 10 + '0';
        str[2] = (int)(number) % 10 + '0';
        str[3] = '.';
        str[4] = (int)(number * 10) % 10 + '0';
        str[5] = (int)(number * 100) % 10 + '0';
        str[6] = (int)(number * 1000) % 100 + '0';
    }
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}



void TFT_display_float3_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor)
{
    char str[8] = {32, 32, 32, 32, 32, 32, 32, 32};  //32�����ո�ȫ����ʼ��Ϊ��
    if (number >= 0)
        str[0] = ' ';
    else {
        str[0] = '-';
        number = -number;
    }
    str[1] = (int)(number) / 1000 + '0';
    str[2] = (int)(number) % 1000 / 100 + '0';
    str[3] = (int)(number) % 100 / 10 + '0';
    str[4] = (int)(number) % 10 + '0';
    str[5] = '.';
    str[6] = (int)(number * 10) % 10 + '0';
    str[7] = (int)(number * 100) % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}

void TFT_display_float4_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor)
{
    char str[7] = {32, 32, 32, 32, 32, 32, 32};   //32�����ո�ȫ����ʼ��Ϊ��
    if (number >= 0)
        str[0] = ' ';
    else {
        str[0] = '-';
        number = -number;
    }
    str[1] = (int)(number) / 100 + '0';
    str[2] = (int)(number) % 100 / 10 + '0';
    str[3] = (int)(number) % 10 + '0';
    str[4] = '.';
    str[5] = (int)(number * 10) % 10 + '0';
    str[6] = (int)(number * 100) % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}



void TFT_display_float5_number_small(int16_t x, int16_t y, float number, uint16_t fColor,  uint16_t bColor)
{
    char str[5] = {32, 32, 32, 32, 32};     //32�����ո�ȫ����ʼ��Ϊ��
    str[0] = (int)(number) % 100 / 10 + '0';
    str[1] = (int)(number) % 10 + '0';
    str[2] = '.';
    str[3] = (int)(number * 10) % 10 + '0';
    str[4] = (int)(number * 100) % 10 + '0';
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}
void TFT_display_char(int16_t x, int16_t y, char a, uint16_t fColor,  uint16_t bColor)
{
    char str[1] = {32};         //32�����ո�ȫ����ʼ��Ϊ��
    str[0] = a;
    TFT320_Write_String(x, y, (uint8_t *)str, fColor,  bColor);
}

/********************************************************************
��������:��һ��int16������ת���ɶ�Ӧ���ַ�����ʽ
��������:int16_to_string
��ʽ����:number ��Ҫת������
         *str   ת����ɵ�����
����ֵ:  ��
�޸���:  kofee
�޸�ʱ��:2014/5/13
*********************************************************************/
void int16_to_string(int16_t number, char *str)
{
    uint16_t temp1, temp2;
    uint8_t len = 0;           //���ֳ���
    if (number == 0) {
        str[0] = '0';
        len++;
    }
    else {
        temp1 = temp2 = number >= 0 ? number : -number;
        while (temp1) {      //�����ֳ���
            temp1 /= 10;
            len++;
        }
        if (number < 0) {
            str[0] = '-';
        }
        while (temp2) { //�Ӻ���ǰ������
            str[len--] = temp2 % 10 + '0';
            temp2 /= 10;
        }
    }
}

void uint16_to_string(uint16_t number, char *str)
{
    uint16_t temp1, temp2;
    uint8_t len = 0;           //���ֳ���
    if (number == 0) {
        str[0] = '0';
        len++;
    }
    else {
        temp1 = temp2 = number;
        while (temp1) {      //�����ֳ���
            temp1 /= 10;
            len++;
        }
        while (temp2) { //�Ӻ���ǰ������
            str[len--] = temp2 % 10 + '0';
            temp2 /= 10;
        }
    }
}

void uint32_to_string(uint32_t number, char *str)
{
    uint32_t temp1, temp2;
    uint8_t len = 0;           //���ֳ���
    if (number == 0) {
        str[0] = '0';
        len++;
    }
    else {
        temp1  = number;
        temp2  = number;
        while (temp1) {      //�����ֳ���
            temp1 /= 10;
            len++;
        }
        while (temp2) { //�Ӻ���ǰ������
            str[len--] = temp2 % 10 + '0';
            temp2 /= 10;
        }
    }
}

void uint32_small_to_string(uint32_t number, char *str)   //С��
{
    uint32_t temp1, temp2;
    uint8_t len = 0;           //���ֳ���
    if (number == 0) {
        str[0] = '0';
        //len++;
    }
    else {
        temp1  = number;
        temp2  = number;
        while (temp1) {      //�����ֳ���
            temp1 /= 10;
            len++;
        }
        temp1 = len;
        while (temp2) { //�Ӻ���ǰ������
            str[--len] = temp2 % 10 + '0';
            temp2 /= 10;
        }
        if (temp1 > 3) {
            temp2 = temp1 - 3;
            for (len = temp1; len > temp2; len--) {
                str[len] = str[len - 1];
            }
        }
        else {
            for (len = temp1 + 1; len > 1; len--) {
                str[len] = str[len - 2];
            }
            str[0] = '0';
        }
        str[len] = '.';
    }
}






void TFT320_write_line(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, uint16_t fColor)
{
    uint16_t j = 0;
    TFT320_LCD_SetPos(x, x + xx - 1, y, y + yy - 1);
    for (j = 0; j < (xx * yy); j++) {
        TFT320_Write_Data_Cmd(1, fColor); //д����
        //DELAY_MS(100);
    }
}

/*          ����״ͼ
            x   :x ��ʼλ��
            y   :y ��ʼλ��
            xx  :��״ͼ�ܿ���       xx Ҫ���� len
            yy  :��״ͼ�ܸ߶�
*/

void TFT320_write_Bar_Chart(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, uint16_t *data, uint16_t len , uint16_t fColor)
{
    uint16_t j = 0, temp1, x_width;
    float y_width;
    temp1 = *data;
    for (j = 0; j < len; j++) {
        if ((*data) > temp1) {   //ȡ���ֵ
            temp1 = *data;
        }
        data++;
    }
    data -= len;
    y_width = (float)yy / (float)temp1; //      //��Сֵ        Ĭ����Сֵ�� 0
    x_width = xx / len  ;
    TFT320_write_line(x , y , 1 , yy , fColor);
    TFT320_write_line(x , yy + y , xx , 1 , fColor);
    for (j = 0; j < len; j++) {
        TFT320_write_line(x + j * x_width , (yy + y) - (uint16_t)((*data)*y_width) , 1 , (uint16_t)((*data)*y_width) , fColor);
        data++;
    }
    x_width = yy / 20;
    for (j = 0; j < x_width; j++) {
        TFT_display_unsign_number_6x8(0, y + 20 * j , (uint16_t)(((float)temp1 / x_width) * (x_width - j)), Red , White);
    }
}


void TFT320_write_Bar_Chart1(float *data)
{
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , (150 - (uint16_t)((*data) * 100)), 1 , 0 , Red);
    data++;
    TFT320_write_line(25 , 0, 1 , (150 - (uint16_t)((*data) * 100)) , Red);
    data -= 8;
}



void TFT320_write_Chart()
{
    // uint16_t x_width;
    // float y_width;
    //y_width = 40; //      //��Сֵ        Ĭ����Сֵ�� 0
    //x_width = 40;
    //  TFT320_write_line( 0 , 0 , 1 ,50 , Red);
    //TFT320_write_line(  40 , 40 , 1 ,240 , Red);
    // TFT320_write_line( 40 , 0 , 1 ,192 , Red);
    TFT320_write_line(80 , 40 , 1 , 240 , Red);
    // TFT320_write_line( 120 , 0 , 1 ,192 , Red);
    TFT320_write_line(160 , 40 , 1 , 240 , Red);
    // TFT320_write_line( 200 , 0 , 1 ,192 , Red);
    TFT320_write_line(240 , 40 , 1 , 240 , Red);
    TFT320_write_line(0 , 40 , 240 , 1 , Red);
    TFT320_write_line(0 , 80 , 240 , 1 , Red);
    TFT320_write_line(0 , 120 , 240 , 1 , Red);
    TFT320_write_line(0 , 160 , 240 , 1 , Red);
    TFT320_write_line(0 , 200 , 240 , 1 , Red);
    TFT320_write_line(0 , 240 , 240 , 1 , Red);
    TFT320_write_line(0 , 280 , 240 , 1 , Red);
}


/**����ͼ  */
//���� ad ��������ͺ�
void TFT320_Point_Chart(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor)
{
    int16_t j = 0, temp1, temp2;
    float y_width;
    temp1 = *data;
    temp1 = 0;
    temp2 = 4096;
    for (j = 0; j < xx; j++) {
        if ((*data) >= temp1) {  //ȡ���ֵ
            temp1 = *data;
        }
        else if ((*data) < temp2) {
            temp2 = *data;
        }
        data++;
    }
    data -= xx;
    y_width = (float)((float)(yy) / (float)temp1);  //      //��Сֵ        Ĭ����Сֵ�� 0
    TFT320_write_line(x , y , 1 , yy , Black);
    TFT320_write_line(x , (yy + y) - (uint16_t)(((temp2 + temp1) / 2)*y_width) , xx , 1 , Black);
    for (j = 1; j < xx; j++) {
        // TFT320_write_line( x+j , y , 1 ,yy , White);
        TFT320_write_line(x + j , (yy + y) - (uint16_t)((*data)*y_width) , 1 , 1 , Red);
        data++;
    }
    TFT320_write_line(x - 1 , y + 1 , 3 , 1 , Black);
    TFT320_write_line(x + xx - 2 , y + yy - 1 , 1 , 3 , Black);
    // TFT320_write_line( 0 , 160 , 240 ,1 , Black);
}
void TFT320_Point_Chart1(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor)
{
    int16_t j = 0, temp1, temp2;
    float y_width;
    temp1 = *data;
    temp1 = 0;
    temp2 = 4096;
    for (j = 0; j < xx; j++) {
        if ((*data) >= temp1) {  //ȡ���ֵ
            temp1 = *data;
        }
        else if ((*data) < temp2) {
            temp2 = *data;
        }
        data++;
    }
    data -= xx;
    y_width = (float)((float)(yy) / (float)temp1);  //      //��Сֵ        Ĭ����Сֵ�� 0
    TFT320_write_line(x , y , 1 , yy , Black);
    TFT320_write_line(x , (yy + y) - (uint16_t)(((temp2 + temp1) / 2)*y_width) , xx , 1 , Black);
    for (j = 1; j < xx; j++) {
        // TFT320_write_line( x+j , y , 1 ,yy , White);
        TFT320_write_line(x + j , (yy + y) - (uint16_t)((*data)*y_width) , 1 , 1 , Red);
        data++;
    }
    TFT320_write_line(x - 1 , y + 1 , 3 , 1 , Black);
    TFT320_write_line(x + xx - 2 , y + yy - 1 , 1 , 3 , Black);
}

void TFT320_Point_Chart2(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor)
{
    int16_t j = 0, temp1;
    float y_width;
    temp1 = *data;
    for (j = 0; j < xx; j++) {
        if ((*data) > temp1) {   //ȡ���ֵ
            temp1 = *data;
        }
        data++;
    }
    data -= xx;
    y_width = (float)((float)(yy) / (float)temp1);  //      //��Сֵ        Ĭ����Сֵ�� 0
    TFT320_write_line(x , y , 1 , yy , Black);
    TFT320_write_line(x , yy + y , xx , 1 , Black);
    for (j = 1; j < xx; j++) {
        //TFT320_write_line( x+j , y , 1 ,yy , White);
        TFT320_write_line(x + j , (yy + y) - (uint16_t)((*data)*y_width) , 1 , 1 , Red);
        data++;
    }
    TFT320_write_line(x - 1 , y + 1 , 3 , 1 , Black);
    TFT320_write_line(x + xx - 2 , y + yy - 1 , 1 , 3 , Black);
}

void TFT320_Point_Chart3(uint16_t x, uint16_t y, uint16_t xx, uint16_t yy, int *data , uint16_t fColor)
{
    int16_t j = 0, temp1;
    float y_width;
    temp1 = *data;
    for (j = 0; j < xx; j++) {
        if ((*data) > temp1) {   //ȡ���ֵ
            temp1 = *data;
        }
        data++;
    }
    data -= xx;
    y_width = (float)((float)(yy) / (float)temp1);  //      //��Сֵ        Ĭ����Сֵ�� 0
    TFT320_write_line(x , y , 1 , yy , Black);
    TFT320_write_line(x , yy + y , xx , 1 , Black);
    for (j = 1; j < xx; j++) {
        //TFT320_write_line( x+j , y , 1 ,yy , White);
        TFT320_write_line(x + j , (yy + y) - (uint16_t)((*data)*y_width) , 1 , 1 , Red);
        data++;
    }
    TFT320_write_line(x - 1 , y + 1 , 3 , 1 , Black);
    TFT320_write_line(x + xx - 2 , y + yy - 1 , 1 , 3 , Black);
}
